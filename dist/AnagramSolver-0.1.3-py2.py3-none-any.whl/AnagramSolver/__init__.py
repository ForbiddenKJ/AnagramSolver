# __init__

# Modules
from anagram import Solve
